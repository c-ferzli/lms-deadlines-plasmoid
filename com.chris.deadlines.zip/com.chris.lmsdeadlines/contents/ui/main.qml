import QtQuick 2.15
import org.kde.plasma.plasmoid 2.0
import org.kde.plasma.components 3.0 as PC3
import org.kde.plasma.plasma5support 2.0 as Plasma5Support
import org.kde.kirigami 2.20 as Kirigami

PlasmoidItem {
    id: root
    preferredRepresentation: compactRepresentation

    property int refreshMinutes: (plasmoid.configuration.refreshMinutes > 0) ? plasmoid.configuration.refreshMinutes : 5
    property int refreshMs: refreshMinutes * 60000
    property bool enableNotifications: plasmoid.configuration.enableNotifications
    property int soonHours: (plasmoid.configuration.soonHours > 0) ? plasmoid.configuration.soonHours : 24
    property int urgentHours: (plasmoid.configuration.urgentHours > 0) ? plasmoid.configuration.urgentHours : 6
    property int cooldownMinutes: (plasmoid.configuration.notifyCooldownMinutes >= 0) ? plasmoid.configuration.notifyCooldownMinutes : 180
    property int quizWindowDays: (plasmoid.configuration.quizWindowDays > 0) ? plasmoid.configuration.quizWindowDays : 30
    property string baseUrl: plasmoid.configuration.baseUrl || "https://lms.aub.edu.lb"
    property string storagePath: plasmoid.configuration.storagePath || "~/.local/share/lmsdeadlines/storage_state.json"

    // 0 = Homeworks, 1 = Quizzes
    property int activeTab: 0

    property bool hasError: false
    property bool loginRequired: false
    property string errText: ""
    property var items: []
    property string lastUpdated: ""
    property bool refreshing: false

    property bool quizzesHasError: false
    property string quizzesErrText: ""
    property var quizItems: []
    property string quizzesLastUpdated: ""
    property bool quizzesRefreshing: false

    property var notifyState: ({})
    property var lastTickTime: new Date()
    property bool justWoke: false

    toolTipMainText: loginRequired ? "LMS Deadlines (Login required)" : (hasError ? "LMS Deadlines (Error)" : ("LMS Deadlines (" + items.length + " hw)"))
    toolTipSubText: loginRequired ? "Click the widget and hit Login" : (hasError ? errText : (items.length ? (items[0].course + " — " + items[0].title) : "No deadlines"))

    function openUrl(url) {
        urlOpener.connectSource("bash -lc " + JSON.stringify("~/.local/share/lmsdeadlines/open_tab.sh " + url));
    }

    function decodeHtml(s) {
        if (!s) return "";
        return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
                .replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&nbsp;/g, " ");
    }

    function parseOutput(txt) {
        var out = [];
        var lines = (txt || "").split("\n");
        for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (!line || line === "No upcoming deadlines" || line === "No quizzes found" || line === "LOGIN_REQUIRED") continue;
            var parts = line.split(" | ");
            if (parts.length < 5) continue;
            out.push({ course: decodeHtml(parts[0]), title: decodeHtml(parts[1]), due: parts[2], remain: parts[3], url: parts[4] });
        }
        return out;
    }

    function remainToMinutes(rem) {
        if (!rem) return 999999;
        if (rem.indexOf("OVERDUE") !== -1) return -1;
        var d = 0, h = 0, m = 0;
        var md = rem.match(/(\d+)\s*d/); var mh = rem.match(/(\d+)\s*h/); var mm = rem.match(/(\d+)\s*m/);
        if (md) d = parseInt(md[1]); if (mh) h = parseInt(mh[1]); if (mm) m = parseInt(mm[1]);
        return d * 1440 + h * 60 + m;
    }

    function hash01(s) {
        var x = 0;
        for (var i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) >>> 0;
        return (x % 10000) / 10000.0;
    }

    function hsvToRgb(h, s, v) {
        var i = Math.floor(h * 6); var f = h * 6 - i;
        var p = v*(1-s); var q = v*(1-f*s); var t = v*(1-(1-f)*s);
        var r, g, b;
        switch (i % 6) {
            case 0: r=v;g=t;b=p; break; case 1: r=q;g=v;b=p; break; case 2: r=p;g=v;b=t; break;
            case 3: r=p;g=q;b=v; break; case 4: r=t;g=p;b=v; break; case 5: r=v;g=p;b=q; break;
        }
        return Qt.rgba(r, g, b, 1);
    }

    function accentColor(course, title) { return hsvToRgb(hash01(course + "|2|" + title), 0.55, 0.95); }

    function dueColor(remain, isQuiz) {
        var mins = remainToMinutes(remain);
        if (isQuiz) {
            if (mins < 0) return Kirigami.Theme.negativeTextColor;
            if (mins < 2 * 24 * 60) return Kirigami.Theme.negativeTextColor;
            if (mins < 5 * 24 * 60) return Kirigami.Theme.neutralTextColor;
            return Kirigami.Theme.positiveTextColor;
        }
        if (mins < 0) return Kirigami.Theme.negativeTextColor;
        if (mins <= urgentHours * 60) return Kirigami.Theme.negativeTextColor;
        if (mins <= soonHours * 60) return Kirigami.Theme.neutralTextColor;
        return Kirigami.Theme.positiveTextColor;
    }

    function cardTint(remain, isQuiz) {
        var mins = remainToMinutes(remain);
        if (isQuiz) {
            if (mins < 0) return Qt.rgba(1,0,0,0.08);
            if (mins < 2 * 24 * 60) return Qt.rgba(1,0,0,0.07);
            if (mins < 5 * 24 * 60) return Qt.rgba(1,1,0,0.06);
            return Qt.rgba(0,1,0,0.05);
        }
        if (mins < 0) return Qt.rgba(1,0,0,0.08);
        if (mins <= urgentHours * 60) return Qt.rgba(1,0,0,0.07);
        if (mins <= soonHours * 60) return Qt.rgba(1,1,0,0.06);
        return Qt.rgba(0,1,0,0.05);
    }

    function remainChipColor(remain, isQuiz) {
        var mins = remainToMinutes(remain);
        if (isQuiz) {
            if (mins < 0) return "#8b1d1d";
            if (mins < 2 * 24 * 60) return "#a62121";
            if (mins < 5 * 24 * 60) return "#8a6d00";
            return "#1f6f3f";
        }
        if (mins < 0) return "#8b1d1d";
        if (mins <= urgentHours * 60) return "#a62121";
        if (mins <= soonHours * 60) return "#8a6d00";
        return "#1f6f3f";
    }

    function localPath(urlObj) { return decodeURIComponent(urlObj.toString().replace(/^file:\/\//, "")); }
    function runnerFile() { return localPath(Qt.resolvedUrl("../scripts/run_deadlines.sh")); }
    function bootstrapFile() { return localPath(Qt.resolvedUrl("../scripts/bootstrap.sh")); }
    function refreshLoginFile() { return localPath(Qt.resolvedUrl("../scripts/refresh_login.py")); }

    function sendNotify(urgency, title, body) {
        var cmd = "notify-send -u " + urgency + " -- " + JSON.stringify(title) + " " + JSON.stringify(body);
        notifier.connectSource("bash -lc " + JSON.stringify(cmd));
    }

    function maybeNotify(listItems, sourceKind) {
        return; // Desktop popup notifications disabled by request.
        if (sourceKind !== "homework") return; // Never notify for quizzes
        if (!enableNotifications || !listItems || listItems.length === 0) return;
        var now = Date.now();
        var cooldownMs = cooldownMinutes * 60000;
        for (var i = 0; i < listItems.length; i++) {
            var it = listItems[i];
            var mins = remainToMinutes(it.remain);
            if (mins <= 0) continue;
            var keyBase = it.course + "|" + it.title + "|" + it.due;
            if (mins <= urgentHours * 60) {
                var kU = "U|" + keyBase; var lastU = notifyState[kU] || 0;
                if (cooldownMs === 0 || (now - lastU) > cooldownMs) { notifyState[kU] = now; sendNotify("critical", "🚨 Urgent deadline", it.course + "\n" + it.title + "\nDue: " + it.due + " (" + it.remain + ")"); }
                continue;
            }
            if (mins <= soonHours * 60) {
                var kS = "S|" + keyBase; var lastS = notifyState[kS] || 0;
                if (cooldownMs === 0 || (now - lastS) > cooldownMs) { notifyState[kS] = now; sendNotify("normal", "⏰ Deadline soon", it.course + "\n" + it.title + "\nDue: " + it.due + " (" + it.remain + ")"); }
            }
        }
    }

    function doRefresh() { root.refreshing = true; exe.disconnectSource(exe.command()); exe.connectSource(exe.command()); }
    function doQuizzesRefresh() { root.quizzesRefreshing = true; quizExe.disconnectSource(quizExe.command()); quizExe.connectSource(quizExe.command()); }

    function doLogin() {
        var cmd = "\"" + bootstrapFile() + "\" \"" + refreshLoginFile() + "\"" + " --base-url \"" + baseUrl + "\" --storage \"" + storagePath + "\"";
        loginRunner.connectSource("bash -lc " + JSON.stringify(cmd));
    }

    Timer {
        interval: 30000; running: true; repeat: true
        onTriggered: {
            var now = new Date(); var elapsed = now - root.lastTickTime;
            if (elapsed > 120000) { root.justWoke = true; wakeDelayTimer.restart(); }
            root.lastTickTime = now;
        }
    }

    Timer { id: wakeDelayTimer; interval: 8000; repeat: false; onTriggered: { root.justWoke = false; root.doRefresh(); root.doQuizzesRefresh(); } }

    Plasma5Support.DataSource {
        id: exe
        engine: "executable"
        interval: Math.max(1000, root.refreshMs)
        connectedSources: [ command() ]
        function command() {
            var cmd = "\"" + root.runnerFile() + "\" --plain --base-url \"" + root.baseUrl + "\" --storage \"" + root.storagePath + "\"";
            return "bash -lc " + JSON.stringify(cmd);
        }
        onNewData: function(sourceName, data) {
            root.refreshing = false;
            var stdout = (data["stdout"] || "").trim();
            var stderr = (data["stderr"] || "").trim();
            var code = data["exit code"];
            if (stdout.indexOf("LOGIN_REQUIRED") !== -1) { root.loginRequired = true; root.hasError = false; root.errText = "Your session expired. Click Login below."; root.items = []; return; }
            root.loginRequired = false;
            if (stderr.length > 0 || code !== 0) { root.hasError = true; root.errText = stderr.length ? stderr : ("Exit code: " + code); root.items = []; }
            else { root.hasError = false; root.errText = ""; root.items = root.parseOutput(stdout); root.maybeNotify(root.items, "homework"); root.lastUpdated = Qt.formatTime(new Date(), "hh:mm"); }
        }
    }

    Plasma5Support.DataSource {
        id: quizExe
        engine: "executable"
        interval: 60 * 60 * 1000
        connectedSources: [ command() ]
        function command() {
            var cmd = "\"" + root.runnerFile() + "\" --plain --quizzes --window-days " + root.quizWindowDays + " --base-url \"" + root.baseUrl + "\" --storage \"" + root.storagePath + "\"";
            return "bash -lc " + JSON.stringify(cmd);
        }
        onNewData: function(sourceName, data) {
            root.quizzesRefreshing = false;
            var stdout = (data["stdout"] || "").trim();
            var stderr = (data["stderr"] || "").trim();
            var code = data["exit code"];
            if (stdout.indexOf("LOGIN_REQUIRED") !== -1) { root.loginRequired = true; root.quizItems = []; return; }
            if (stderr.length > 0 || code !== 0) { root.quizzesHasError = true; root.quizzesErrText = stderr.length ? stderr : ("Exit code: " + code); root.quizItems = []; }
            else { root.quizzesHasError = false; root.quizzesErrText = ""; root.quizItems = root.parseOutput(stdout); root.quizzesLastUpdated = Qt.formatTime(new Date(), "hh:mm"); }
        }
    }

    Plasma5Support.DataSource { id: notifier; engine: "executable"; onNewData: function(sourceName, data) { notifier.disconnectSource(sourceName); } }
    Plasma5Support.DataSource { id: loginRunner; engine: "executable"; onNewData: function(sourceName, data) { loginRunner.disconnectSource(sourceName); root.doRefresh(); root.doQuizzesRefresh(); } }
    Plasma5Support.DataSource { id: urlOpener; engine: "executable"; onNewData: function(sourceName, data) { urlOpener.disconnectSource(sourceName); } }

    compactRepresentation: Item {
        implicitWidth: 34; implicitHeight: 34
        MouseArea { anchors.fill: parent; onClicked: root.expanded = !root.expanded }
        Image {
            anchors.centerIn: parent; width: 22; height: 22
            source: (root.hasError || root.loginRequired) ? "" : Qt.resolvedUrl("../images/lms.svg")
            fillMode: Image.PreserveAspectFit; smooth: true
            visible: !(root.hasError || root.loginRequired)
            opacity: root.refreshing ? 0.4 : 1.0
            Behavior on opacity { NumberAnimation { duration: 300 } }
        }
        Kirigami.Icon { anchors.centerIn: parent; width: 22; height: 22; source: root.loginRequired ? "dialog-password" : "dialog-error"; visible: root.hasError || root.loginRequired }
        Rectangle {
            visible: !root.hasError && !root.loginRequired && root.items.length > 0
            anchors.right: parent.right; anchors.top: parent.top; anchors.rightMargin: 1; anchors.topMargin: 1
            radius: 8; implicitHeight: 16; implicitWidth: Math.max(16, badgeText.implicitWidth + 8)
            color: Kirigami.Theme.highlightColor
            PC3.Label { id: badgeText; anchors.centerIn: parent; text: String(root.items.length); color: Kirigami.Theme.highlightedTextColor; font.pixelSize: 10 }
        }
    }

    fullRepresentation: Item {
        implicitWidth: 520
        implicitHeight: 420

        Rectangle {
            anchors.fill: parent; anchors.margins: 10
            radius: 12; color: Kirigami.Theme.backgroundColor
            border.width: 1; border.color: Kirigami.Theme.disabledTextColor

            // Header
            Item {
                id: header; anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top; height: 44
                Image { anchors.left: parent.left; anchors.leftMargin: 12; anchors.verticalCenter: parent.verticalCenter; width: 20; height: 20; source: Qt.resolvedUrl("../images/lms.svg"); fillMode: Image.PreserveAspectFit; smooth: true; visible: !(root.hasError || root.loginRequired) }
                Kirigami.Icon { anchors.left: parent.left; anchors.leftMargin: 12; anchors.verticalCenter: parent.verticalCenter; width: 20; height: 20; source: root.loginRequired ? "dialog-password" : "dialog-error"; visible: root.hasError || root.loginRequired }
                PC3.Label {
                    anchors.left: parent.left; anchors.leftMargin: 44; anchors.right: headerRight.left; anchors.rightMargin: 8; anchors.verticalCenter: parent.verticalCenter
                    text: root.loginRequired ? "LMS Deadlines — Login required" : (root.hasError ? "LMS Deadlines — Error" : "LMS Deadlines")
                    font.bold: true; elide: Text.ElideRight
                    color: (root.hasError || root.loginRequired) ? Kirigami.Theme.negativeTextColor : Kirigami.Theme.textColor
                }
                Row {
                    id: headerRight; anchors.right: parent.right; anchors.rightMargin: 8; anchors.verticalCenter: parent.verticalCenter; spacing: 4
                    PC3.Label {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: root.activeTab === 0 ? root.lastUpdated !== "" : root.quizzesLastUpdated !== ""
                        text: root.activeTab === 0 ? (root.refreshing ? "Refreshing…" : ("Updated " + root.lastUpdated)) : (root.quizzesRefreshing ? "Scanning…" : ("Updated " + root.quizzesLastUpdated))
                        color: Kirigami.Theme.disabledTextColor; font.pixelSize: 10
                    }
                    PC3.ToolButton {
                        anchors.verticalCenter: parent.verticalCenter; icon.name: "view-refresh"
                        enabled: root.activeTab === 0 ? !root.refreshing : !root.quizzesRefreshing
                        opacity: (root.activeTab === 0 ? root.refreshing : root.quizzesRefreshing) ? 0.4 : 1.0
                        onClicked: { if (root.activeTab === 0) root.doRefresh(); else root.doQuizzesRefresh(); }
                        PC3.ToolTip.text: "Refresh now"; PC3.ToolTip.visible: hovered
                    }
                }
            }

            Rectangle { id: sep; anchors.left: parent.left; anchors.right: parent.right; anchors.top: header.bottom; height: 1; color: Kirigami.Theme.disabledTextColor; opacity: 0.6 }

            // Tab bar
            Item {
                id: tabBar; anchors.left: parent.left; anchors.right: parent.right; anchors.top: sep.bottom; height: 42

                Row {
                    anchors.centerIn: parent; spacing: 8

                    Rectangle {
                        width: 148; height: 30; radius: 8
                        color: root.activeTab === 0 ? Kirigami.Theme.highlightColor : "transparent"
                        border.width: root.activeTab === 0 ? 0 : 1; border.color: Kirigami.Theme.disabledTextColor
                        Row { anchors.centerIn: parent; spacing: 6
                            Kirigami.Icon { source: "document-edit"; width: 14; height: 14; color: root.activeTab === 0 ? Kirigami.Theme.highlightedTextColor : Kirigami.Theme.textColor }
                            PC3.Label { text: "Homeworks (" + root.items.length + ")"; font.pixelSize: 12; font.bold: root.activeTab === 0; color: root.activeTab === 0 ? Kirigami.Theme.highlightedTextColor : Kirigami.Theme.textColor }
                        }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.activeTab = 0 }
                        Behavior on color { ColorAnimation { duration: 150 } }
                    }

                    Rectangle {
                        width: 148; height: 30; radius: 8
                        color: root.activeTab === 1 ? Kirigami.Theme.highlightColor : "transparent"
                        border.width: root.activeTab === 1 ? 0 : 1; border.color: Kirigami.Theme.disabledTextColor
                        Row { anchors.centerIn: parent; spacing: 6
                            Kirigami.Icon { source: "help-contents"; width: 14; height: 14; color: root.activeTab === 1 ? Kirigami.Theme.highlightedTextColor : Kirigami.Theme.textColor }
                            PC3.Label { text: "Quizzes (" + root.quizItems.length + ")"; font.pixelSize: 12; font.bold: root.activeTab === 1; color: root.activeTab === 1 ? Kirigami.Theme.highlightedTextColor : Kirigami.Theme.textColor }
                        }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.activeTab = 1 }
                        Behavior on color { ColorAnimation { duration: 150 } }
                    }
                }
            }

            Rectangle { id: sep2; anchors.left: parent.left; anchors.right: parent.right; anchors.top: tabBar.bottom; height: 1; color: Kirigami.Theme.disabledTextColor; opacity: 0.4 }

            // Login panel
            Column {
                visible: root.loginRequired
                anchors.left: parent.left; anchors.right: parent.right; anchors.top: sep2.bottom; anchors.bottom: parent.bottom; anchors.margins: 16; spacing: 12
                PC3.Label { width: parent.width; wrapMode: Text.WordWrap; text: root.errText; color: Kirigami.Theme.negativeTextColor }
                PC3.Button { text: "Login to LMS"; icon.name: "dialog-password"; onClicked: root.doLogin() }
                PC3.Label { width: parent.width; wrapMode: Text.WordWrap; text: "A browser window will open. Log in and it will close automatically.\nTip: tick 'Remember me' to stay logged in longer."; color: Kirigami.Theme.disabledTextColor; font.pixelSize: 11 }
            }

            PC3.TextArea { visible: root.hasError && !root.loginRequired && root.activeTab === 0; anchors.left: parent.left; anchors.right: parent.right; anchors.top: sep2.bottom; anchors.bottom: parent.bottom; anchors.margins: 12; readOnly: true; wrapMode: TextEdit.Wrap; text: root.errText; color: Kirigami.Theme.negativeTextColor }
            PC3.TextArea { visible: root.quizzesHasError && !root.loginRequired && root.activeTab === 1; anchors.left: parent.left; anchors.right: parent.right; anchors.top: sep2.bottom; anchors.bottom: parent.bottom; anchors.margins: 12; readOnly: true; wrapMode: TextEdit.Wrap; text: root.quizzesErrText; color: Kirigami.Theme.negativeTextColor }

            // List
            PC3.ScrollView {
                visible: !root.loginRequired && !(root.activeTab === 0 && root.hasError) && !(root.activeTab === 1 && root.quizzesHasError)
                anchors.left: parent.left; anchors.right: parent.right; anchors.top: sep2.bottom; anchors.bottom: parent.bottom; anchors.margins: 12

                ListView {
                    id: list
                    model: root.activeTab === 0 ? root.items : root.quizItems
                    clip: true; spacing: 10
                    onVisibleChanged: if (visible) Qt.callLater(positionViewAtBeginning)

                    delegate: Rectangle {
                        width: list.width; radius: 12; color: Kirigami.Theme.alternateBackgroundColor
                        implicitHeight: content.implicitHeight + 20; height: implicitHeight

                        transform: Translate { y: cardMouse.containsMouse ? -3 : 0; Behavior on y { NumberAnimation { duration: 120; easing.type: Easing.OutQuad } } }
                        Rectangle { anchors.fill: parent; radius: 12; color: root.cardTint(modelData.remain, root.activeTab === 1) }
                        Rectangle { anchors.fill: parent; radius: 12; color: "white"; opacity: cardMouse.containsMouse ? 0.07 : 0.0; Behavior on opacity { NumberAnimation { duration: 120 } } }
                        Rectangle { width: 6; anchors.left: parent.left; anchors.top: parent.top; anchors.bottom: parent.bottom; radius: 12; color: root.accentColor(modelData.course, modelData.title); opacity: 0.95 }

                        MouseArea { id: cardMouse; anchors.fill: parent; cursorShape: Qt.PointingHandCursor; hoverEnabled: true; onClicked: root.openUrl(modelData.url) }

                        Column {
                            id: content
                            width: parent.width - 6 - 24; anchors.left: parent.left; anchors.leftMargin: 18; anchors.top: parent.top; anchors.topMargin: 10; spacing: 6
                            PC3.Label { width: parent.width; text: modelData.course; font.bold: true; wrapMode: Text.WordWrap; color: Kirigami.Theme.textColor }
                            PC3.Label { width: parent.width; text: modelData.title; wrapMode: Text.WordWrap; color: Kirigami.Theme.textColor }
                            Row {
                                spacing: 10
                                PC3.Label {
                                    id: dueLabel
                                    width: Math.max(90, content.width - remainLabel.implicitWidth - dotLabel.implicitWidth - 20)
                                    elide: Text.ElideRight
                                    text: modelData.due
                                    color: Kirigami.Theme.disabledTextColor
                                    font.pixelSize: 11
                                }
                                PC3.Label { id: dotLabel; text: "•"; color: Kirigami.Theme.disabledTextColor; font.pixelSize: 11 }
                                Rectangle {
                                    radius: 6
                                    color: root.remainChipColor(modelData.remain, root.activeTab === 1)
                                    implicitHeight: remainLabel.implicitHeight + 4
                                    implicitWidth: remainLabel.implicitWidth + 10
                                    PC3.Label {
                                        id: remainLabel
                                        anchors.centerIn: parent
                                        text: modelData.remain
                                        color: "white"
                                        font.bold: true
                                        font.pixelSize: 12
                                    }
                                }
                            }
                        }
                    }

                    footer: Item {
                        width: list.width
                        height: (root.activeTab === 0 ? root.items.length : root.quizItems.length) === 0 ? 70 : 0
                        visible: (root.activeTab === 0 ? root.items.length : root.quizItems.length) === 0
                        Column {
                            anchors.centerIn: parent; spacing: 8
                            PC3.BusyIndicator { anchors.horizontalCenter: parent.horizontalCenter; width: 24; height: 24; visible: root.activeTab === 1 && root.quizzesRefreshing; running: visible }
                            PC3.Label {
                                anchors.horizontalCenter: parent.horizontalCenter
                                text: (root.activeTab === 1 && root.quizzesRefreshing) ? "Scanning Moodle pages & syllabi…" : (root.activeTab === 0 ? "No upcoming deadlines" : ("No quizzes found in next " + root.quizWindowDays + " days"))
                                color: Kirigami.Theme.disabledTextColor
                            }
                        }
                    }
                }
            }
        }
    }
}
