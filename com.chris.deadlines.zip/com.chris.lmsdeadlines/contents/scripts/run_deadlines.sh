#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"

# If --quizzes flag is passed, run the quizzes extractor instead
if [[ " $* " == *" --quizzes "* ]]; then
    ARGS=()
    for arg in "$@"; do
        [[ "$arg" == "--quizzes" ]] || ARGS+=("$arg")
    done
    exec "$DIR/bootstrap.sh" "$DIR/extract_quizzes.py" "${ARGS[@]}" 2>/dev/null
else
    exec "$DIR/bootstrap.sh" "$DIR/extract_deadlines.py" "$@" 2>/dev/null
fi
