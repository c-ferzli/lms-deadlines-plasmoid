#!/usr/bin/env python3
from __future__ import annotations

import argparse
import html as ihtml
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse, parse_qs

from playwright.sync_api import sync_playwright

try:
    from pypdf import PdfReader  # type: ignore
except Exception:
    PdfReader = None  # type: ignore


# ---- Regex ----
SESSKEY_RE = re.compile(r'"sesskey"\s*:\s*"([^"]+)"|sesskey\s*=\s*\'([^\']+)\'', re.I)
COURSE_ID_RE = re.compile(r"/course/view\.php\?id=(\d+)")
QUIZ_LINK_RE = re.compile(r'[^"\']*(/mod/quiz/(?:view|attempt)\.php\?[^"\']+)', re.I)

# Anchor parser: href + inner text (good enough for Moodle pages)
A_TAG_RE = re.compile(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.I | re.S)

TAG_RE = re.compile(r"<[^>]+>")
WS_RE = re.compile(r"[ \t]+")
MULTI_NL_RE = re.compile(r"\n\s*\n+")
NBSP_RE = re.compile(r"\xa0|&nbsp;", re.I)

SYLLABUS_HINT = re.compile(r"\b(syllabus|course\s*outline|outline|schedule)\b", re.I)
QUIZ_WORD = re.compile(r"\bquiz\b", re.I)
QUIZ_LABEL = re.compile(r"\bquiz\s*(?:#|no\.?|number)?\s*0*(\d+)\b", re.I)
MIDTERM_WORD = re.compile(r"\bmid[\s-]*term\b", re.I)
MIDTERM_LABEL = re.compile(r"\bmid[\s-]*term\s*(?:#|no\.?|number)?\s*0*(\d+)\b", re.I)
ASSESSMENT_WORD = re.compile(r"\b(quiz|mid[\s-]*term)\b", re.I)
NOISE_CONTEXT_RE = re.compile(
    r"\b(recent\s+activity|activity\s+since|full\s+report\s+of\s+recent\s+activity|"
    r"contacts|messages|settings|skip\s+activities|skip\s+recent\s+activity)\b",
    re.I,
)
SCHEDULE_HINT_RE = re.compile(
    r"\b(due|exam|mid[\s-]*term|quiz\s*\d+|on\s+\w+|from|until|closes?|opens?|postpon\w*|reschedul\w*|moved?\s+to|changed?\s+to|new\s+date)\b",
    re.I,
)
MOODLE_ACTIVITY_EXCLUDE_RE = re.compile(
    r"\b(pre[\s-]*lab|lab\s*\d+|manual|assignment|homework|worksheet|project|"
    r"closes?|opens?|available\s+from|available\s+until|attempt|submission)\b",
    re.I,
)

# Quiz page often has "Opens:" / "Closes:" / "Available from"
QUIZ_DATE_HINT = re.compile(r"\b(opens|closes|available\s+from|available\s+until|open|close)\b.{0,200}", re.I)

MONTHS = {
    "jan": 1, "january": 1,
    "feb": 2, "february": 2,
    "mar": 3, "march": 3,
    "apr": 4, "april": 4,
    "may": 5,
    "jun": 6, "june": 6,
    "jul": 7, "july": 7,
    "aug": 8, "august": 8,
    "sep": 9, "sept": 9, "september": 9,
    "oct": 10, "october": 10,
    "nov": 11, "november": 11,
    "dec": 12, "december": 12,
}

DATE_REGEXES = [
    re.compile(r"\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})\b"),  # dd/mm/yyyy
    re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b"),               # yyyy-mm-dd
    re.compile(
        r"\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|"
        r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2})"
        r"(?:st|nd|rd|th)?[,]?\s+(\d{4})\b", re.I
    ),
    re.compile(
        r"\b(\d{1,2})(?:st|nd|rd|th)?\s+"
        r"(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|"
        r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{4})\b", re.I
    ),
    re.compile(  # dd/mm with no year
        r"\b(\d{1,2})[\/\-.](\d{1,2})\b"
    ),
    re.compile(  # Month dd with no year
        r"\b(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|"
        r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+(\d{1,2})(?:st|nd|rd|th)?\b", re.I
    ),
    re.compile(  # dd Month with no year
        r"\b(\d{1,2})(?:st|nd|rd|th)?\s+"
        r"(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|"
        r"Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\b", re.I
    ),
]


def eprint(*a: Any) -> None:
    print(*a, file=sys.stderr)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    # Keep compatibility with your existing wrapper/QML
    p.add_argument("--plain", action="store_true")
    p.add_argument("--limit", type=int, default=200)
    p.add_argument("--base-url", default=os.environ.get("LMS_BASE_URL", "https://lms.aub.edu.lb"))
    p.add_argument("--storage", default=os.environ.get("LMS_STORAGE_STATE", "~/.local/share/lmsdeadlines/storage_state.json"))
    p.add_argument("--max", type=int, default=80)
    p.add_argument("--overdue-cutoff-days", type=int, default=1)
    p.add_argument("--window-days", type=int, default=14)
    p.add_argument("--debug", action="store_true")
    return p.parse_args()


def has_sesskey(html: str) -> bool:
    return bool(SESSKEY_RE.search(html or ""))


def html_to_text(s: str) -> str:
    s = ihtml.unescape(s)
    s = NBSP_RE.sub(" ", s)
    s = s.replace("\r", "\n")
    s = TAG_RE.sub(" ", s)
    s = WS_RE.sub(" ", s)
    s = MULTI_NL_RE.sub("\n", s)
    return s.strip()


def parse_first_date(text: str) -> Optional[datetime]:
    t = text.strip()
    now = datetime.now()
    for rx in DATE_REGEXES:
        m = rx.search(t)
        if not m:
            continue
        g = m.groups()
        try:
            if rx is DATE_REGEXES[0]:
                d = int(g[0]); mo = int(g[1]); y = int(g[2])
                if y < 100:
                    y += 2000
                return datetime(y, mo, d)
            if rx is DATE_REGEXES[1]:
                y = int(g[0]); mo = int(g[1]); d = int(g[2])
                return datetime(y, mo, d)
            if rx is DATE_REGEXES[2]:
                mo = MONTHS[g[0].lower()[:3]]
                d = int(g[1]); y = int(g[2])
                return datetime(y, mo, d)
            if rx is DATE_REGEXES[3]:
                d = int(g[0]); mo = MONTHS[g[1].lower()[:3]]; y = int(g[2])
                return datetime(y, mo, d)
            if rx is DATE_REGEXES[4]:
                d = int(g[0]); mo = int(g[1]); y = now.year
                cand = datetime(y, mo, d)
                if cand < now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0) - timedelta(days=2):
                    cand = datetime(y + 1, mo, d)
                return cand
            if rx is DATE_REGEXES[5]:
                mo = MONTHS[g[0].lower()[:3]]; d = int(g[1]); y = now.year
                cand = datetime(y, mo, d)
                if cand < now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0) - timedelta(days=2):
                    cand = datetime(y + 1, mo, d)
                return cand
            if rx is DATE_REGEXES[6]:
                d = int(g[0]); mo = MONTHS[g[1].lower()[:3]]; y = now.year
                cand = datetime(y, mo, d)
                if cand < now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0) - timedelta(days=2):
                    cand = datetime(y + 1, mo, d)
                return cand
        except Exception:
            continue
    return None


def parse_best_date(text: str) -> Optional[datetime]:
    candidates: List[datetime] = []
    for rx in DATE_REGEXES:
        for m in rx.finditer(text):
            d = parse_first_date(m.group(0))
            if d:
                candidates.append(d)
    if not candidates:
        return None
    now = datetime.now()
    near_or_future = [d for d in candidates if d >= now - timedelta(days=1)]
    if near_or_future:
        return min(near_or_future)
    return max(candidates)


def parse_first_date_by_position(text: str) -> Optional[datetime]:
    hits: List[Tuple[int, datetime]] = []
    for rx in DATE_REGEXES:
        for m in rx.finditer(text):
            d = parse_first_date(m.group(0))
            if d:
                hits.append((m.start(), d))
    if not hits:
        return None
    hits.sort(key=lambda x: x[0])
    return hits[0][1]


def friendly_due(due: datetime) -> str:
    return due.strftime("%A %-d %B at %H:%M")


def time_remaining_plain(due: datetime) -> str:
    now = datetime.now()
    delta = due - now
    if delta.total_seconds() < 0:
        return "OVERDUE"
    days = delta.days
    hours, rem = divmod(delta.seconds, 3600)
    minutes = rem // 60
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if not days and not hours:
        parts.append(f"{minutes}m")
    return " ".join(parts)


def pdf_text_from_bytes(b: bytes) -> str:
    if PdfReader is None:
        return ""
    try:
        import io
        reader = PdfReader(io.BytesIO(b))
        parts: List[str] = []
        for page in reader.pages:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                continue
        return "\n".join(parts)
    except Exception:
        return ""


@dataclass
class QuizItem:
    course: str
    title: str
    date_text: str
    when: Optional[datetime]
    url: str
    due_text: str = ""


def course_name_from_page(html: str, fallback: str) -> str:
    m = re.search(r"<h1[^>]*>(.*?)</h1>", html, flags=re.I | re.S)
    if m:
        t = html_to_text(m.group(1)).strip()
        if t:
            return t
    m = re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.I | re.S)
    if m:
        t = html_to_text(m.group(1)).strip()
        if t:
            return t
    return fallback


def clean_course_name(name: str) -> str:
    cleaned = re.sub(r"^\s*course\s*:\s*", "", name, flags=re.I).strip()
    return cleaned or name.strip()


def find_syllabus_pdf_links(base_url: str, html: str) -> List[str]:
    found: List[str] = []
    for href, inner in A_TAG_RE.findall(html):
        text = html_to_text(inner)
        absu = urljoin(base_url + "/", href)

        # detect syllabus by link text OR URL/filename/query
        parsed = urlparse(absu)
        qs = parse_qs(parsed.query)
        filename_bits = " ".join(sum(qs.values(), []))  # flatten query values
        haystack = f"{text} {absu} {filename_bits}"

        if not re.search(r"syllabus", haystack, re.I):
            continue

        path = parsed.path.lower()
        # Moodle often uses resource/view.php indirection before serving pluginfile PDF.
        if (
            path.endswith(".pdf")
            or "pluginfile.php" in path
            or "draftfile.php" in path
            or "/mod/resource/view.php" in path
        ):
            found.append(absu)

    # uniq keep order
    seen = set()
    uniq: List[str] = []
    for u in found:
        if u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq[:6]


def extract_pdf_links_from_html(base_url: str, html: str) -> List[str]:
    links: List[str] = []
    for href, _inner in A_TAG_RE.findall(html):
        absu = urljoin(base_url + "/", href)
        parsed = urlparse(absu)
        path = parsed.path.lower()
        if path.endswith(".pdf") or "pluginfile.php" in path or "draftfile.php" in path:
            links.append(absu)
    seen = set()
    uniq: List[str] = []
    for u in links:
        if u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq


def infer_title(line: str) -> str:
    qm = QUIZ_LABEL.search(line)
    if qm:
        num = str(int(qm.group(1)))
        return f"Quiz {num}"
    mm = MIDTERM_LABEL.search(line)
    if mm:
        num = str(int(mm.group(1)))
        return f"Midterm {num}"
    if QUIZ_WORD.search(line):
        return "Quiz"
    if MIDTERM_WORD.search(line):
        return "Midterm"
    return "Assessment"


def is_noise_context(text: str) -> bool:
    return bool(NOISE_CONTEXT_RE.search(text))


def has_schedule_hint(text: str) -> bool:
    return bool(SCHEDULE_HINT_RE.search(text))


def is_moodle_activity_quiz(text: str) -> bool:
    # Exclude course activities hosted/completed on Moodle (e.g., lab quizzes).
    if not QUIZ_WORD.search(text):
        return False
    return bool(MOODLE_ACTIVITY_EXCLUDE_RE.search(text))


def parse_assessment_info(text: str) -> Tuple[Optional[datetime], str]:
    # Prefer dates that are explicitly tied to postponement/rescheduling notices.
    for kw in re.finditer(r"(?i)\b(postpon\w*|reschedul\w*|moved?\s+to|changed?\s+to|new\s+date)\b", text):
        tail = text[kw.end(): kw.end() + 220]
        stop = tail.find(".")
        segment = tail[:stop + 1] if stop >= 0 else tail
        d = parse_first_date_by_position(segment)
        if d:
            return d, segment

    for m in ASSESSMENT_WORD.finditer(text):
        tail = text[m.end(): m.end() + 220]
        d = parse_best_date(tail)
        if d:
            return d, tail
    return parse_best_date(text), text


def extract_time_and_location(text: str) -> Tuple[Optional[Tuple[int, int]], str, str]:
    t = re.sub(r"\s+", " ", text)

    # Exact time (12-hour)
    m = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", t, re.I)
    if m:
        h = int(m.group(1)) % 12
        if m.group(3).lower() == "pm":
            h += 12
        minute = int(m.group(2) or "0")
        time_hint = f"{h:02d}:{minute:02d}"
    else:
        # Exact time (24-hour)
        m24 = re.search(r"\b([01]?\d|2[0-3]):([0-5]\d)\b", t)
        if m24:
            h = int(m24.group(1))
            minute = int(m24.group(2))
            time_hint = f"{h:02d}:{minute:02d}"
        else:
            h = -1
            minute = -1
            time_hint = ""

    exact: Optional[Tuple[int, int]] = (h, minute) if time_hint else None
    time_text = ""
    if exact is None:
        part = re.search(r"\b(morning|afternoon|evening|noon)\b", t, re.I)
        if part:
            time_text = part.group(1).lower()

    location = ""
    loc_patterns = [
        r"\b(room|rm\.?|lab|hall|auditorium|building)\s*[:#-]?\s*([A-Za-z0-9][A-Za-z0-9\- ]{0,24})",
        r"\b(online|zoom|microsoft teams|teams)\b",
    ]
    for p in loc_patterns:
        lm = re.search(p, t, re.I)
        if lm:
            location = re.sub(r"\s+", " ", lm.group(0)).strip(" ,.;")
            break

    return exact, time_text, location


def build_due_text_and_when(date_only: datetime, context: str) -> Tuple[datetime, str]:
    exact, part_of_day, location = extract_time_and_location(context)
    day_dt = datetime(date_only.year, date_only.month, date_only.day)

    if exact:
        when = day_dt.replace(hour=exact[0], minute=exact[1])
        due_text = when.strftime("%A %-d %B at %H:%M")
    else:
        # If exact time is unknown, assume end-of-day for remaining-time calculations.
        when = day_dt.replace(hour=23, minute=59)
        due_text = when.strftime("%A %-d %B")
        if part_of_day:
            due_text += f" ({part_of_day})"

    if location:
        if len(location) > 42:
            location = location[:39].rstrip() + "..."
        due_text += f" - {location}"

    return when, due_text


def extract_from_course_page(course: str, course_url: str, course_html: str) -> List[QuizItem]:
    items: List[QuizItem] = []
    text = html_to_text(course_html)
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if not ASSESSMENT_WORD.search(line):
            continue
        if is_noise_context(line):
            continue
        if is_moodle_activity_quiz(line):
            continue
        if not has_schedule_hint(line):
            continue
        d, ctx = parse_assessment_info(line)
        if not d:
            continue
        when, due_text = build_due_text_and_when(d, ctx)
        items.append(
            QuizItem(
                course=course,
                title=infer_title(line),
                date_text=re.sub(r"\s+", " ", line)[:180],
                when=when,
                url=course_url,
                due_text=due_text,
            )
        )

    # Fallback: page layouts sometimes split label/date across lines; scan around match.
    if not items:
        flat = re.sub(r"\s+", " ", text)
        for m in ASSESSMENT_WORD.finditer(flat):
            snippet = flat[max(0, m.start() - 100): m.end() + 180]
            if is_noise_context(snippet):
                continue
            if is_moodle_activity_quiz(snippet):
                continue
            if not has_schedule_hint(snippet):
                continue
            d, ctx = parse_assessment_info(snippet)
            if not d:
                continue
            when, due_text = build_due_text_and_when(d, ctx)
            items.append(
                QuizItem(
                    course=course,
                    title=infer_title(snippet),
                    date_text=snippet[:180],
                    when=when,
                    url=course_url,
                    due_text=due_text,
                )
            )

    return items


def extract_from_syllabus_pdf(course: str, pdf_url: str, pdf_text: str, debug: bool) -> List[QuizItem]:
    items: List[QuizItem] = []
    if not pdf_text:
        if debug:
            eprint(f"[DEBUG] empty PDF text: {course} -> {pdf_url}")
        return items

    text = re.sub(r"[ \t]+", " ", pdf_text)

    for line in text.splitlines():
        if not ASSESSMENT_WORD.search(line):
            continue
        d = parse_first_date(line)
        if not d:
            continue
        title = infer_title(line)
        date_text = re.sub(r"\s+", " ", line.strip())
        when, due_text = build_due_text_and_when(d, line)
        items.append(QuizItem(course=course, title=title, date_text=date_text[:180], when=when, url=pdf_url, due_text=due_text))

    # Fallback for table-like PDFs where quiz/midterm and date are not on same line.
    if not items:
        flat = re.sub(r"\s+", " ", text)
        for m in ASSESSMENT_WORD.finditer(flat):
            snippet = flat[max(0, m.start() - 120): m.end() + 260]
            d = parse_first_date(snippet)
            if not d:
                continue
            when, due_text = build_due_text_and_when(d, snippet)
            items.append(
                QuizItem(
                    course=course,
                    title=infer_title(snippet),
                    date_text=snippet[:180],
                    when=when,
                    url=pdf_url,
                    due_text=due_text,
                )
            )

    # Local de-dup.
    dedup: Dict[Tuple[str, str], QuizItem] = {}
    for it in items:
        k = (it.title, it.when.strftime("%Y-%m-%d") if it.when else "")
        dedup[k] = it
    items = list(dedup.values())

    if debug and not items:
        eprint(f"[DEBUG] syllabus PDF found but no quiz+date lines: {course} -> {pdf_url}")

    return items


def sort_items(items: List[QuizItem]) -> List[QuizItem]:
    def key(it: QuizItem) -> Tuple[int, float, str]:
        if it.when is None:
            return (1, float("inf"), it.title)
        return (0, it.when.timestamp(), it.title)
    return sorted(items, key=key)


def safe_get(reqctx, url: str, timeout_ms: int = 30000):
    try:
        return reqctx.get(url, timeout=timeout_ms)
    except Exception:
        return None


def main() -> int:
    ARGS = parse_args()
    base = ARGS.base_url.rstrip("/")
    dash_url = f"{base}/my/"
    cutoff = datetime.now() - timedelta(days=int(ARGS.overdue_cutoff_days))
    window_days = max(1, int(ARGS.window_days))
    horizon = datetime.now() + timedelta(days=window_days)

    storage_path = Path(os.path.expanduser(ARGS.storage))
    if not storage_path.exists() or storage_path.stat().st_size < 50:
        print("LOGIN_REQUIRED")
        return 0

    with sync_playwright() as p:
        reqctx = p.request.new_context(storage_state=str(storage_path))

        dash = reqctx.get(dash_url)
        if not dash.ok or not has_sesskey(dash.text()):
            if ARGS.debug:
                eprint(f"[DEBUG] /my/ ok={dash.ok} status={dash.status} url={dash.url}")
            print("LOGIN_REQUIRED")
            return 0

        dash_html = dash.text()
        course_ids = sorted({int(x) for x in COURSE_ID_RE.findall(dash_html)})

        if not course_ids:
            crs = reqctx.get(f"{base}/my/courses.php")
            if crs.ok:
                course_ids = sorted({int(x) for x in COURSE_ID_RE.findall(crs.text())})

        if ARGS.debug:
            eprint(f"[DEBUG] discovered course ids: {course_ids}")

        if not course_ids:
            print("No quizzes found")
            return 0

        all_items: List[QuizItem] = []

        for cid in course_ids:
            course_url = f"{base}/course/view.php?id={cid}"
            cr = safe_get(reqctx, course_url, timeout_ms=45000)
            if not cr or not cr.ok:
                if ARGS.debug:
                    status = cr.status if cr else "EXC"
                    eprint(f"[DEBUG] course page failed: id={cid} HTTP {status}")
                continue

            course_html = cr.text()
            course_name = clean_course_name(course_name_from_page(course_html, f"Course {cid}"))

            # 1) Course page first and authoritative for this course.
            course_items_all = [it for it in extract_from_course_page(course_name, course_url, course_html) if it.when and it.when >= cutoff]
            if course_items_all:
                course_items = [it for it in course_items_all if it.when and it.when <= horizon]
                if ARGS.debug:
                    if course_items:
                        eprint(f"[DEBUG] {course_name}: found {len(course_items)} item(s) on course page; skipping syllabus PDF")
                    else:
                        eprint(f"[DEBUG] {course_name}: course page has assessments but all are outside {window_days}-day window; skipping syllabus PDF")
                all_items.extend(course_items)
                continue

            # 2) Fallback: syllabus PDF only (if course page had no date hits).
            pdf_links = find_syllabus_pdf_links(base, course_html)
            if ARGS.debug:
                eprint(f"[DEBUG] {course_name}: syllabus PDFs: {len(pdf_links)}")

            for pdf_url in pdf_links:
                pr = safe_get(reqctx, pdf_url, timeout_ms=120000)
                if not pr or not pr.ok:
                    if ARGS.debug:
                        status = pr.status if pr else "EXC"
                        eprint(f"[DEBUG] PDF download failed: HTTP {status} {pdf_url}")
                    continue
                body = pr.body()
                if body[:4] != b"%PDF":
                    # Support resource indirection pages that embed actual pluginfile PDF links.
                    html = pr.text()
                    embedded_pdfs = extract_pdf_links_from_html(base, html)
                    if not embedded_pdfs:
                        if ARGS.debug:
                            eprint(f"[DEBUG] not PDF bytes and no embedded PDF link: {pdf_url}")
                        continue
                    if ARGS.debug:
                        eprint(f"[DEBUG] resolved resource to {len(embedded_pdfs)} embedded PDF link(s): {pdf_url}")
                    resolved = False
                    for emb in embedded_pdfs[:3]:
                        pr2 = safe_get(reqctx, emb, timeout_ms=120000)
                        if not pr2 or not pr2.ok:
                            continue
                        body2 = pr2.body()
                        if body2[:4] != b"%PDF":
                            continue
                        txt = pdf_text_from_bytes(body2)
                        pdf_items = [it for it in extract_from_syllabus_pdf(course_name, emb, txt, ARGS.debug) if it.when and cutoff <= it.when <= horizon]
                        all_items.extend(pdf_items)
                        resolved = True
                    if not resolved and ARGS.debug:
                        eprint(f"[DEBUG] resource resolved but no readable PDF bytes: {pdf_url}")
                    continue
                txt = pdf_text_from_bytes(body)
                pdf_items = [it for it in extract_from_syllabus_pdf(course_name, pdf_url, txt, ARGS.debug) if it.when and cutoff <= it.when <= horizon]
                all_items.extend(pdf_items)

        # Keep only items with a parseable date; skip unknown-date noise.
        all_items = [it for it in all_items if it.when is not None]

        if not all_items:
            print("No quizzes found")
            return 0

        # Dedup by stable identity while allowing multiple events per URL/course.
        uniq: Dict[Tuple[str, str, str, str], QuizItem] = {}
        for it in all_items:
            when_key = it.when.strftime("%Y-%m-%d") if it.when else ""
            uniq[(it.course, it.title, when_key, it.url)] = it
        items = sort_items(list(uniq.values()))[: max(1, ARGS.max)]

        for it in items:
            if it.when:
                due_txt = it.due_text if it.due_text else friendly_due(it.when)
                print(f"{it.course} | {it.title} | {due_txt} | {time_remaining_plain(it.when)} | {it.url}")
            else:
                print(f"{it.course} | {it.title} | {it.date_text} | ? | {it.url}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
