#!/usr/bin/env bash
set -euo pipefail

VENV_DIR="${LMS_VENV_DIR:-$HOME/.local/share/lmsdeadlines/venv}"
PY="$VENV_DIR/bin/python"

mkdir -p "$(dirname "$VENV_DIR")"

if [ ! -x "$PY" ]; then
  python3 -m venv "$VENV_DIR"
fi

"$PY" -m pip install -U pip setuptools wheel >/dev/null

if ! "$PY" -c "import playwright" >/dev/null 2>&1; then
  "$PY" -m pip install -U playwright
fi

if ! "$PY" -c "import pypdf" >/dev/null 2>&1; then
  "$PY" -m pip install -U pypdf
fi

if ! "$PY" -c "import docx" >/dev/null 2>&1; then
  "$PY" -m pip install -U python-docx
fi

if ! "$PY" -c "import requests" >/dev/null 2>&1; then
  "$PY" -m pip install -U requests
fi

# Only install Chromium if it isn't already present in Playwright cache
if ! ls "$HOME/.cache/ms-playwright"/chromium-* >/dev/null 2>&1; then
  "$PY" -m playwright install chromium
fi

exec "$PY" "$@"
