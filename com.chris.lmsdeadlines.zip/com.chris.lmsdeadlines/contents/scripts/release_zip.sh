#!/usr/bin/env bash
set -euo pipefail

# Script location: .../com.chris.lmsdeadlines/contents/scripts/release_zip.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"     # local plasmoid folder
SOURCE_PARENT="$(cd "$SOURCE_DIR/.." && pwd)"

ZIP_NAME="com.chris.lmsdeadlines.zip"
OLD_ZIP_NAME="com.chris.deadlines.zip"
PACKAGE_PATH="$SOURCE_PARENT/$ZIP_NAME"

# Use repo remote if available, otherwise fallback to explicit repo URL.
REMOTE_URL="$(git -C "$SOURCE_DIR" remote get-url origin 2>/dev/null || true)"
if [ -z "$REMOTE_URL" ]; then
  REMOTE_URL="git@github.com:c-ferzli/lms-deadlines-plasmoid.git"
fi

echo "Building package from: $SOURCE_DIR"
rm -f "$PACKAGE_PATH"
(
  cd "$SOURCE_PARENT"
  zip -r "$PACKAGE_PATH" "$(basename "$SOURCE_DIR")" \
    -x "$(basename "$SOURCE_DIR")/.git/*" \
    -x "$(basename "$SOURCE_DIR")/**/.git/*" \
    -x "$(basename "$SOURCE_DIR")/**/__pycache__/*" \
    -x "$(basename "$SOURCE_DIR")/**/*.pyc" \
    -x "$(basename "$SOURCE_DIR")/*.zip" \
    -x "$(basename "$SOURCE_DIR")/*.plasmoid"
)

TMP_CLONE="$(mktemp -d /tmp/lms-release.XXXXXX)"
cleanup() { rm -rf "$TMP_CLONE"; }
trap cleanup EXIT

echo "Cloning clean repo to: $TMP_CLONE"
git clone "$REMOTE_URL" "$TMP_CLONE" >/dev/null

cp "$PACKAGE_PATH" "$TMP_CLONE/$ZIP_NAME"

if git -C "$TMP_CLONE" ls-files --error-unmatch "$OLD_ZIP_NAME" >/dev/null 2>&1; then
  git -C "$TMP_CLONE" rm -f "$OLD_ZIP_NAME" >/dev/null
fi

git -C "$TMP_CLONE" add "$ZIP_NAME"

if git -C "$TMP_CLONE" diff --cached --quiet; then
  echo "No zip changes to commit."
  exit 0
fi

git -C "$TMP_CLONE" config user.name "${GIT_AUTHOR_NAME:-c-ferzli}"
git -C "$TMP_CLONE" config user.email "${GIT_AUTHOR_EMAIL:-c-ferzli@users.noreply.github.com}"

git -C "$TMP_CLONE" commit -m "Update release zip ($ZIP_NAME)" >/dev/null
git -C "$TMP_CLONE" push origin main

echo "Done: pushed updated $ZIP_NAME"
