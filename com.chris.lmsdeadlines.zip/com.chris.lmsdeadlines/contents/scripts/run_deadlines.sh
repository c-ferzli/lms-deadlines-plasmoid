#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"

# Run bootstrap quietly so widget doesn't show pip warnings
exec "$DIR/bootstrap.sh" "$DIR/extract_deadlines.py" "$@" 2>/dev/null
